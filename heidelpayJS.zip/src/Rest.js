import querystring from 'querystring'
import fetch from 'fetch-everywhere'

/**
 * Rest
 * Private class, not exported in main.js
 * @class
 * @property {string} endpoint - API endpoint
 **/
class Rest {

  constructor(endpoint) {
    this._endpoint = endpoint
  }

  get(options) {
    const {
      path,
      token,
      queryParams
    } = options

    const url = `${this._endpoint}/${path}`,
          headers = this._createHeaders(token)

    return this._call(url, { headers }, queryParams)
  }

  post(options) {
    const {
      path,
      token,
      payload,
      queryParams
    } = options

    const url = `${this._endpoint}/${path}`,
          headers = this._createHeaders(token)

    const enveloppe = {
      headers: headers,
      method: 'POST',
      body: JSON.stringify(payload || {})
    }

    return this._call(url, enveloppe, queryParams)
  }

  _createHeaders(token) {
    let headers = {
      'Content-Type': 'application/json'
    }

    if (token) {
      headers = Object.assign(headers, {
        Authorization: `Bearer ${token}`
      })
    }

    return headers
  }

  _call(url, enveloppe, queryParams) {
    return new Promise((resolve, reject) => {
      if(queryParams) {
        url = `${url}?${querystring.stringify(queryParams)}`
      }

      fetch(url, enveloppe)
        .then(response => {
          resolve(response.json())
        })
        .catch(err => {
          reject(err)
        })
    })
  }
}

export default Rest