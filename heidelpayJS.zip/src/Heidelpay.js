import Exception from './Exception'
/**
 * Heidelpay
 * @class
 * @property {string} privateKey 
 * @property {string} locale
 **/
export default class Heidelpay {
  constructor(privateKey, locale = 'en-US') {
		if (!privateKey) {
			throw new Exception('Private key is required')
		}
		this.privateKey = privateKey
		this.locale = locale
	}
}