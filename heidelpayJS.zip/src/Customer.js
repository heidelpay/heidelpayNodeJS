/**
 * Customer
 * @class
 * @property {string} firstName
 * @property {string} lastName
 **/
export default class Customer {
  constructor(firstName = '', lastName = '') {
    this.firstName = firstName
    this.lastName = lastName
  }
}