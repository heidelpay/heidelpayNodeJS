class PaymentType {
	constructor() {
		this.baseURL = '/v1/types'
		this.operations = ['create', 'fetch', 'update', 'del', 'delete', 'list']
	}
}

export default PaymentType