import PaymentType from "../PaymentType";

export default class Card extends PaymentType {
  constructor(number = '', expiryDate = '', cvc = '') {
    super()
    this.number = number
    this.expiryDate = expiryDate
    this.cvc = cvc
  }  
  
}