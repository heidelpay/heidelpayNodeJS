const assert = require('assert');
const Heidelpay = require('..').Heidelpay;
const Exception = require('..').Exception;

function test() {
	assert.throws(function() {
		new Heidelpay()
	}, Exception)

	console.log(`\u001B[32m✓\u001B[39m Exception throw when no private key`);
}

test();